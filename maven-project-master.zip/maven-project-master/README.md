# maven-project
how to build: mvn package
how to generate code coverage: jacoco
how to execute unit test framework: junit
It generates  artifact: war file
